import discord
from discord.ext import commands
import random

# Set up intents for accessing specific events
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Create the bot instance
bot = commands.Bot(command_prefix="!", intents=intents)

# Dictionary to store user points for the economy system
user_points = {}

# Event to signal when the bot is online
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

# ---------------------- Basic Commands ----------------------

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

@bot.command()
async def help(ctx):
    commands_list = """
    **Available Commands:**
    - `!ping` - Check if the bot is active
    - `!help` - Get a list of available commands
    - `!kick @user` - Kick a user from the server (admin only)
    - `!ban @user` - Ban a user from the server (admin only)
    - `!roll [number]` - Roll a random number
    - `!eightball [question]` - Ask the Magic 8-Ball a question
    - `!userinfo @user` - Get info about a user
    - `!addrole @user [RoleName]` - Add a role to a user
    - `!removerole @user [RoleName]` - Remove a role from a user
    - `!balance` - Check your points balance
    - `!give @user [amount]` - Give points to a user
    """
    await ctx.send(commands_list)

# ---------------------- Moderation Commands ----------------------

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f'User {member} has been kicked for {reason}.')

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f'User {member} has been banned for {reason}.')

# ---------------------- Role Management ----------------------

@bot.command()
@commands.has_permissions(manage_roles=True)
async def addrole(ctx, user: discord.Member, role: discord.Role):
    await user.add_roles(role)
    await ctx.send(f'Role {role.name} added to {user.mention}.')

@bot.command()
@commands.has_permissions(manage_roles=True)
async def removerole(ctx, user: discord.Member, role: discord.Role):
    await user.remove_roles(role)
    await ctx.send(f'Role {role.name} removed from {user.mention}.')

# ---------------------- Logging Events ----------------------

@bot.event
async def on_member_join(member):
    channel = discord.utils.get(member.guild.channels, name="welcome")
    if channel:
        await channel.send(f"Welcome {member.mention} to the server!")

@bot.event
async def on_member_remove(member):
    channel = discord.utils.get(member.guild.channels, name="goodbye")
    if channel:
        await channel.send(f"Goodbye {member.mention}, we hope to see you again!")

@bot.event
async def on_message_delete(message):
    channel = discord.utils.get(message.guild.channels, name="logs")
    if channel:
        await channel.send(f"Message by {message.author} deleted: {message.content}")

# ---------------------- Fun Commands ----------------------

@bot.command()
async def roll(ctx, number: int):
    dice_roll = random.randint(1, number)
    await ctx.send(f'You rolled a {dice_roll}!')

@bot.command()
async def eightball(ctx, *, question):
    responses = [
        "Yes.", "No.", "Maybe.", "Ask again later.", "Definitely!", "Absolutely not."
    ]
    await ctx.send(f'Question: {question}\nAnswer: {random.choice(responses)}')

# ---------------------- Economy Commands ----------------------

@bot.command()
async def balance(ctx):
    user = ctx.author
    points = user_points.get(user.id, 0)
    await ctx.send(f"{user.mention}, you have {points} points.")

@bot.command()
async def give(ctx, member: discord.Member, amount: int):
    user_points[member.id] = user_points.get(member.id, 0) + amount
    await ctx.send(f"{ctx.author.mention} gave {amount} points to {member.mention}.")

# ---------------------- Reaction Roles ----------------------

@bot.command()
@commands.has_permissions(manage_roles=True)
async def reaction_role(ctx, message_id: int, emoji, role: discord.Role):
    message = await ctx.fetch_message(message_id)
    await message.add_reaction(emoji)

    @bot.event
    async def on_raw_reaction_add(payload):
        if payload.message_id == message_id:
            guild = discord.utils.find(lambda g: g.id == payload.guild_id, bot.guilds)
            role = discord.utils.get(guild.roles, name=role.name)
            if role:
                await payload.member.add_roles(role)

    @bot.event
    async def on_raw_reaction_remove(payload):
        if payload.message_id == message_id:
            guild = discord.utils.find(lambda g: g.id == payload.guild_id, bot.guilds)
            member = guild.get_member(payload.user_id)
            role = discord.utils.get(guild.roles, name=role.name)
            if role:
                await member.remove_roles(role)

# Run the bot with your token
bot.run('MTI4OTg4NzE2NjQxMDkyMDAzMQ.GVkJ-A.eaXmJeMMMf6G5dbtPOeou0bMcH3u6ImdzDqSzo')